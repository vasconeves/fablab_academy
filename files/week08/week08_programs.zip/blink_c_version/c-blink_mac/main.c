/*
comment
*/
//set your clock speed
#define F_CPU 16000000L
//these are the include files. They are outside the project folder
#include <avr/io.h>
#include <util/delay.h>

int main (void)
{
DDRB = (1<<DDB5);

while(1) {
PINB =(1 << PB5);
_delay_ms(100);
PINB =(0 << PB5);
_delay_ms(100);
};
}
